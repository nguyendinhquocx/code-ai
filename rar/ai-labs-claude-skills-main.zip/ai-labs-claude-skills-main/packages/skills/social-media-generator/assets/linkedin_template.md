# {{EVENT_NAME}}

{{PROFESSIONAL_OPENING}}

{{MAIN_MESSAGE}}

{{KEY_POINTS}}

{{INSIGHTS_OR_TAKEAWAYS}}

{{CALL_TO_ACTION}}

{{HASHTAGS}}

---
Platform: LinkedIn
Character Limit: 3,000 characters
Best Practices:
- Professional and informative tone
- Focus on value, insights, and professional relevance
- Use bullet points for key information
- Include industry-relevant hashtags (3-5)
- Encourage professional engagement (comments, shares)
- Tag relevant companies or professionals
- Consider adding a question to spark discussion
- Use professional imagery
