# {{EVENT_NAME}}

{{MAIN_MESSAGE}}

{{HASHTAGS}}

{{CALL_TO_ACTION}}

---
Platform: Twitter
Character Limit: 280 characters
Best Practices:
- Keep it concise and engaging
- Use 1-3 relevant hashtags
- Include a clear call-to-action
- Consider adding emojis for engagement
- Tag relevant accounts when appropriate
