# {{EVENT_NAME}}

{{MAIN_MESSAGE}}

{{DETAILED_DESCRIPTION}}

{{HASHTAGS}}

{{CALL_TO_ACTION}}

---
Platform: Instagram
Character Limit: 2,200 characters (caption)
Best Practices:
- Use compelling visuals (mention image/video requirements)
- First line should hook the audience
- Use line breaks for readability
- Include 5-15 relevant hashtags
- Encourage engagement (likes, comments, shares)
- Include location tags when relevant
- Consider Instagram Stories for time-sensitive content
