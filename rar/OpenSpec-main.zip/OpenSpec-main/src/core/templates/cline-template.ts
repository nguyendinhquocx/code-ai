export { agentsRootStubTemplate as clineTemplate } from './agents-root-stub.js';
